const express = require('express');
var http = require('http');
const bodyParser = require('body-parser');
const app = express();

var mysql = require('mysql');




var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: '',
  database:'mydb'
});

con.connect(function(err){
    if(err) throw err;
    console.log('connected');
})


app.use(bodyParser.urlencoded({ extended: true })); 

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");

  if(req.method === 'OPTIONS'){
    res.header('Access-Control-Allow-Methods', 'PUT, POST, GET, DELETE, PATCH');
    return res.status(200).json({});
  }
  next();
});




app.post('/manufacturer', (req, res) => {

var query1 = "insert into car values('"+req.body.carid+"','"+req.body.manufacturerid+"','"+req.body.chessisno+
                                  "','"+req.body.modelid+"','"+req.body.color+"','"+req.body.companyname+"')";

var query = "select * from car where carid = '"+req.body.carid+"'";
  
  con.query(query, function(err, result, fields){
     if(err) throw err
     else if(result != 0){
       console.log('Car with this id already registered');
       res.end('Car with this id already registered on the ledger');
     }else{
       con.query(query1, function(err){
         if(err) throw err
         console.log('Car has been added to the ledger');
         res.end("Car has been added to the ledger");
       })
     }
  })    
});


app.post('/sell_to_dealer', (req, res) => {
 
 var query1 = "insert into user_car (carid, dealerid) values('"+req.body.carid+"','"+req.body.dealerid+"')";
 var query = "select * from car where carid = '"+req.body.carid+"' AND manufacturerid = '"+req.body.manufacturerid+"'";
   
   con.query(query, function(err, result, fields){
      if(err) throw err
      else if (result == 0){
        console.log('Invalid input');
        res.end('Invalid input');
      } else {
        con.query(query1, function(err, result, fields){
          if(err) throw err 
          res.end('Car has been sold to dealer');
        })
      }
  
   })    

 });


 app.post('/buy_car', (req, res) => {
 
  var query1 = "update user_car set  userid = '"+req.body.userid+"' where carid = '"+req.body.carid+"'";
  var query = "select * from user_car where carid = '"+req.body.carid+"' AND dealerid = '"+req.body.dealerid+"'";
    
    con.query(query, function(err, result, fields){
       if(err) throw err
       else if (result == 0){
         res.end('Invalid Input');
       }else{
         con.query(query1, function(err, result, fields){
           if(err) throw err
           res.end('Car has been sold to the customer');
         })
       }
   
    })    
  });


  app.post('/insurace_car', (req, res) => {
 
    var query1 = "update user_car set  insurerid = '"+req.body.insurerid+"'where carid = '"+req.body.carid+"'";
    var query = "select * from user_car where carid = '"+req.body.carid+"' AND userid = '"+req.body.userid+"'";
      
      con.query(query, function(err, result, fields){
         if(err) throw err
         else if (result == 0){
           res.end('Invalid input **');
         }
         else {
           con.query(query1, function(err, result, fields){
             if(err) throw err
             res.end('Car has been insured');
           })
         }
     
      })    

    });


    app.post('/approve_by_rta', (req, res) => {
 
      var query1 = "update user_car set  rtaid = '"+req.body.rtaid+"'where carid = '"+req.body.carid+"' AND userid =  '"+req.body.userid+"'";
    var query = "select * from user_car where carid = '"+req.body.carid+"' AND userid = '"+req.body.userid+"'";
      
      con.query(query, function(err, result, fields){
         if(err) throw err
         else if (result == 0){
           res.end('Invalid input');
         }
         else {
           con.query(query1, function(err, result, fields){
             if(err) throw err
             res.end('Car has been authorized by rta');
           })
         }
     
      })    

    });

    

    // sell car to another customer

      app.post('/sell_car', (req, res) => {
 
        var query1 = "update user_car SET  userid = '"+req.body.newownerid+"' where carid = '"+req.body.carid+"'";
        
        var query = "select * from user_car where carid = '"+req.body.carid+"' AND userid =  '"+req.body.carownerid+"'";
          
          con.query(query, function(err, result, fields){
             if(err) throw err
             if(result == 0) {
               res.end('Invalid request');
             } else {
                con.query(query1, function(err, result, fields){
                   if(err) throw err
                   res.end('Car ownership has been transfered');
                })
             }
         
          })    
        });

 // register all stakeholder 


 app.post('/register_manufacturer', (req, res) => {

 var query1 = "insert into reg_manufacturer values('"+req.body.manufacturerid+"', '" +req.body.companyname+"', '" +req.body.mobno+"')";

 var query = "select * from reg_manufacturer where companyid = '"+req.body.companyid+"'";

   
   con.query(query, function(err, result, fields){
      if(err) throw err 
      if(result == 0){
        con.query(query1, function(err, result, fields){
          if (err) throw err
          res.end("Manufacturerd has been registered");
        })
      } else{
        res.end("Manufactuered with this id is already registered");
      }
   })    

 });


 app.post('/register_insurer', (req, res) => {

  var query1 = "insert into reg_insurer values('" +req.body.insuranceid+"', '" +req.body.insurancename+"', '" +req.body.mobno+"')";
  var query = "select * from reg_insurer where insuranceid = '"+req.body.insuranceid+"'";
    
    con.query(query, function(err, result, fields){
       if(err) throw err
       if(result == 0){
        con.query(query1, function(err, result, fields){
          if (err) throw err
          res.end("Insurer has been registered");
        })
      } else{
        res.end("Insurer with this id is already registered");
      }      
    })    
 
  });



  app.post('/register_dealer', (req, res) => {

    var query1 = "insert into reg_dealer values('" +req.body.dealerid+"', '" +req.body.agencyname+"','" +req.body.mobno+"')";
    var query = "select * from reg_dealer where dealerid = '"+req.body.dealerid+"'";
      
      con.query(query, function(err, result, fields){
         if(err) throw err
         if(result == 0){
          con.query(query1, function(err, result, fields){
            if (err) throw err
            res.end("Dealer has been registered");
          })
        } else{
          res.end("Dealer with this id is already registered");
        }
         
      })    
    });


    app.post('/register_rta', (req, res) => {

      var query1 = "insert into reg_rta values('" +req.body.rtaid+"', '" +req.body.rtaname+"', '" +req.body.mobno+"')";
      var query = "select * from reg_rta where rtaid = '"+req.body.rtaid+"'";
        
        con.query(query, function(err, result, fields){
           if(err) throw err
           if(result == 0){
            con.query(query1, function(err, result, fields){
              if (err) throw err
              res.end("RTA has been registered");
            })
          } else{
            res.end("RTA with this id is already registered");
          }
           
        })    

      });


 app.post('/register_user', (req, res) => {

        var query1 = "insert into reg_user values('" +req.body.userid+"', '" +req.body.name+"', " +
                       " '" +req.body.mobno+"', '" +req.body.drivinglic+"')";
        var query = "select * from reg_user where userid = '"+req.body.userid+"'";
          
          con.query(query, function(err, result, fields){
             if(err) throw err
             if(result == 0){
              con.query(query1, function(err, result, fields){
                if (err) throw err
                res.end("User has been registered");
              })
            } else{
              res.end("User with this id is already registered");
            }
             
          })    
});



// show car detail


app.post('/car_info', (req, res) => {

  var query = "select * from user_car where carid = '"+req.body.carid+"'";
    
    con.query(query, function(err, result, fields){
       if(err) throw err
       if(result == 0){
         console.log("888888");
         res.send(result);
       } else
        res.send(result);
    })    
  });


  app.post('/car_manufacturer_info', (req, res) => {

    var query = "select * from car where carid = '"+req.body.carid+"'";
      
      con.query(query, function(err, result, fields){
         if(err) throw err
         if(result == 0){
           res.send(result);
         }
         else
         res.send(result);
      })    
    });




// connection code

const port = 8080;

app.listen(port, () => {
  console.log(`Server running on port${port}`);
});






